<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<?php
//connect
//connect db
	$con = mysqli_connect("localhost","root","","vocab");
?>

